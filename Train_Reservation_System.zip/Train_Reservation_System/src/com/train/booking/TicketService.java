package com.train.booking;

import java.util.LinkedList;
import java.util.List;

public class TicketService {
	private static List<Ticket> allTickets=new LinkedList<>();

	public static void addNewTicket(int trainNumber,List<Passenger> passengerList) {
		// TODO Auto-generated method stub
		int pnr=allTickets.size()+1;
		Train bookedTrain =TrainService.findTrain(trainNumber);
		allTickets.add(new Ticket(pnr,bookedTrain,passengerList));
		System.out.println("tickets booked successfully");
	}
	public static void showTicketsDetails(int pnr) {
		Ticket tempTicket=null;
		for(Ticket t:allTickets) {
			if(t.getPnr()==pnr) {
				tempTicket=t;
				break;
			}
		}
		Train tempTrain=tempTicket.getBookedTrain();
		List<Passenger> passengerList=tempTicket.getPassengerList();
		int totalFare=tempTrain.getFare()*passengerList.size();
		System.out.println("***** Your Booking Details *****");
		System.out.println("PNR NO.=> "+tempTicket.getPnr()+" Train Number=> "+tempTrain.getTrainNumber());
		System.out.println("From Station - "+tempTrain.getFromStation()+" To Station - "+tempTrain.getToStation());
		System.out.println("Date Of Journey - "+tempTrain.getDoj()+" Fare - "+tempTrain.getFare()+" TotalFare - "+totalFare);
		System.out.println("\n Passenger info below\n");
		System.out.println("Passenger Name and age");
		for(Passenger p:passengerList) {
			System.out.println(p.getPassengerName()+" "+p.getAge());
		}System.out.println("*****************************************************");
	}

}
