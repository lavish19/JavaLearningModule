package com.train.booking;

import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;

public class TrainService {
	private static List<Train> allTrains=new LinkedList<>();
	static {
		allTrains.add(new Train(101,"Train-One","hyderabad","banglore",100,900,LocalDate.now()));
		allTrains.add(new Train(102,"Train-Two","bhopal","jodhpur",100,800,LocalDate.now()));
		allTrains.add(new Train(103,"Train-Three","bhopal","ambala",100,900,LocalDate.now()));
		allTrains.add(new Train(104,"Train-Four","kashmir","kanyakumari",100,900,LocalDate.now()));
		allTrains.add(new Train(105,"Train-Five","bhopal","jaipur",100,900,LocalDate.now()));
		allTrains.add(new Train(106,"Train-Six","ajmer","gaya",100,900,LocalDate.now()));
	}
	public TrainService(){
		super();
	}
	public static Train findTrain(int trainNumber) {
		Train temp=null;
		for(Train t:allTrains) {
			if(t.getTrainNumber()==trainNumber) {
				temp=t;
				break;
			}
		}
		return temp;
	}
	public static void searchTrainsBetweenStations(String fromStation,String toStation,LocalDate doj,int numberOfSeats) {
		List<Train> searchTrainList=new LinkedList<>();
		for(Train t:allTrains) {
			if(t.getFromStation().equals(fromStation)&&
					t.getToStation().equals(toStation)&&
					t.getDoj().equals(doj)&&
					t.getSeatsAvailable()>numberOfSeats) {
				searchTrainList.add(t);
			}
		}
	if(searchTrainList.size()==0) {
		System.out.println("sorry,no matching train available");
	}
	else {
	System.out.println("train-number \t train-name \t from station \t to station \t date-of-journey \t seats-available \t fare");
	System.out.println();
	for(Train t:searchTrainList) {
		
	
	System.out.printf("%4d%20s%15s%15s%12s%4d%5d\n",t.getTrainNumber(),t.getTrainName(),t.getFromStation(),t.getToStation(),t.getDoj(),t.getSeatsAvailable(),t.getFare());}}
	}

public static void bookTickets(int trainNumber, List<Passenger> passengerList) {
	int numberOfSeats=passengerList.size();
	BankAccount account= passengerList.get(0).getBankAccount();
	Train tempTrain=findTrain(trainNumber);
	int fare=tempTrain.getFare();
	int totalFare=fare*numberOfSeats;
	account.withdraw(totalFare);
	tempTrain.setSeatsAvailable(tempTrain.getSeatsAvailable()-numberOfSeats);
	TicketService.addNewTicket(trainNumber,passengerList);
}
}