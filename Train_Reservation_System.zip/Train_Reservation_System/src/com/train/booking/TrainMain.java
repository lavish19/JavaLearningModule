package com.train.booking;

import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;

public class TrainMain {
public static void main(String[] args) {
	System.out.println("Now Searching for Trains....");
	TrainService.searchTrainsBetweenStations("bhopal","jaipur",LocalDate.now(), 10);
	BankAccount b1=new BankAccount();
	b1.setActNumber(999);
	b1.setActBalance(10000);
	Passenger p1=new Passenger(10,"Ravi",30,b1);
	Passenger p2=new Passenger(20,"scott",23,b1);
	Passenger p3=new Passenger(30,"bill",43,b1);
	int initialBalance=b1.getActBalance();
	List<Passenger> PassengerList=new LinkedList<>();
	PassengerList.add(p1);
	PassengerList.add(p2);
	PassengerList.add(p3);
	System.out.println("Now Booking Tickets  for 3 Passengers ");
	TrainService.bookTickets(101, PassengerList);
	System.out.println("Now Printing for Ticket Details ");
	TicketService.showTicketsDetails(1);
	System.out.println("\n\n");
	TrainService.searchTrainsBetweenStations("bhopal","jaipur",LocalDate.now(), 10);
	int balanceAfterBookingTickets=b1.getActBalance();
	System.out.println("initial balance - "+initialBalance);
	System.out.println("balance after booking - "+balanceAfterBookingTickets);
}
}
